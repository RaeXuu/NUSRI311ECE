# ============================================
#   PCA + SVM Baseline for Heart Sound Classification
#   OWN CODE for ML baseline
# ============================================

import os
import sys
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

# ---- 把项目根目录加入 sys.path ----
# 假设当前文件在: /mnt/d/MLProj/src/ml/baseline.py
# PROJECT_ROOT = /mnt/d/MLProj
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.append(PROJECT_ROOT)

# ---- 使用 src.xxx 的导入方式（和 dataset.py 保持一致）----
from src.preprocess.load_metadata import load_metadata
from src.preprocess.load_wav import load_wav
from src.preprocess.mel import logmel_fixed_size
from src.preprocess.segment import segment_audio


def extract_logmel(filepath, sr=4000, n_mels=64):
    """
    对单个 WAV 文件：
    1) 重采样到 sr
    2) 切 2 秒 segment（和训练 CNN 时一致）
    3) 取第一个 segment
    4) 转成固定 64×64 的 log-mel
    5) flatten 成向量
    """
    # 读取 & 重采样
    y, sr = load_wav(filepath, target_sr=sr)

    # 切 2 秒片段
    segments = segment_audio(y, sr=sr, segment_sec=2.0)
    if len(segments) == 0:
        return None

    seg = segments[0]

    # 转成固定大小的 64×64 log-mel
    mel = logmel_fixed_size(seg, sr=sr, target_shape=(n_mels, 64))

    # (64, 64) -> 4096 维向量
    return mel.flatten()


def load_dataset(metadata_df):
    """
    从 metadata 逐个 wav 提取特征。
    只保留成功提取特征的样本。
    """
    features, labels = [], []

    for idx, row in metadata_df.iterrows():
        fp = row["filepath"]
        y = row["label"]

        x = extract_logmel(fp)
        if x is None:
            continue

        features.append(x)
        labels.append(y)

    X = np.asarray(features, dtype=np.float32)
    y = np.asarray(labels)
    return X, y


def main():
    print("Loading metadata...")
    meta = load_metadata()
    print(f"Total WAV records in metadata: {len(meta)}")

    print("Extracting log-mel features...")
    X, y = load_dataset(meta)
    print("After feature extraction:")
    print("  X shape:", X.shape)
    print("  y shape:", y.shape)

    # ----------------------------------------
    # Train/test split
    # ----------------------------------------
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # ----------------------------------------
    # PCA
    # ----------------------------------------
    print("Applying PCA...")
    pca = PCA(n_components=50, random_state=42)
    X_train_pca = pca.fit_transform(X_train)
    X_test_pca = pca.transform(X_test)

    # ----------------------------------------
    # SVM
    # ----------------------------------------
    print("Training SVM classifier...")
    svm = SVC(kernel="rbf", C=1.0, gamma="scale")
    svm.fit(X_train_pca, y_train)

    # Evaluation
    y_pred = svm.predict(X_test_pca)
    acc = accuracy_score(y_test, y_pred)

    print("=====================================")
    print(" PCA + SVM BASELINE RESULTS")
    print(" Test Accuracy:", round(acc, 4))
    print("=====================================")


if __name__ == "__main__":
    main()
