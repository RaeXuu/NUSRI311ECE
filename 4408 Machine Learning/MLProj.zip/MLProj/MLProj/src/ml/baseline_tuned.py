import os
import sys
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../.."))
if PROJECT_ROOT not in sys.path:
    sys.path.append(PROJECT_ROOT)

from src.preprocess.load_metadata import load_metadata
from src.preprocess.load_wav import load_wav
from src.preprocess.mel import logmel_fixed_size
from src.preprocess.segment import segment_audio


def extract_logmel(filepath, sr=4000, n_mels=64):
    y, sr = load_wav(filepath, target_sr=sr)
    segments = segment_audio(y, sr=sr, segment_sec=2.0)
    if len(segments) == 0:
        return None
    seg = segments[0]
    mel = logmel_fixed_size(seg, sr=sr, target_shape=(n_mels, 64))
    return mel.flatten()


def load_dataset(metadata_df):
    feats, labels = [], []
    for _, row in metadata_df.iterrows():
        fp = row["filepath"]
        y = row["label"]
        x = extract_logmel(fp)
        if x is None:
            continue
        feats.append(x)
        labels.append(y)
    X = np.asarray(feats, dtype=np.float32)
    y = np.asarray(labels)
    return X, y


def main():
    print("Loading metadata...")
    meta = load_metadata()
    X, y = load_dataset(meta)
    print("X:", X.shape, "y:", y.shape)

    # 先划分 train / test
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # 要尝试的参数
    pca_list = [20, 50, 100]
    C_list = [0.1, 1.0, 10.0]
    gamma_list = ["scale", 0.01, 0.001]

    best_acc = 0.0
    best_cfg = None

    for n_pca in pca_list:
        print(f"\n=== PCA components = {n_pca} ===")
        pca = PCA(n_components=n_pca, random_state=42)
        X_train_pca = pca.fit_transform(X_train)
        X_test_pca = pca.transform(X_test)

        for C in C_list:
            for gamma in gamma_list:
                svm = SVC(kernel="rbf", C=C, gamma=gamma)
                svm.fit(X_train_pca, y_train)
                y_pred = svm.predict(X_test_pca)
                acc = accuracy_score(y_test, y_pred)
                print(f"PCA={n_pca}, C={C}, gamma={gamma} -> acc={acc:.3f}")
                if acc > best_acc:
                    best_acc = acc
                    best_cfg = (n_pca, C, gamma)

    print("\n=====================================")
    print(" Best config:")
    print("  PCA components =", best_cfg[0])
    print("  C =", best_cfg[1])
    print("  gamma =", best_cfg[2])
    print("  Test Accuracy =", round(best_acc, 3))
    print("=====================================")


if __name__ == "__main__":
    main()
